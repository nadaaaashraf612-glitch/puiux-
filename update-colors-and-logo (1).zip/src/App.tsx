import Profile from "./components/Profile";
import { projects } from "./data/projects";

export default function App() {
  return <Profile projects={projects} />;
}
